<?php
	/*
	*Template Name: Home Template
	*/ 
	get_header();
	 while ( have_posts() ) : the_post();
	 $homefeaturedimage = wp_get_attachment_image_src( get_post_thumbnail_id( get_the_ID() ), 'full' ); 
	 
	  
 ?> 
   <div id="primary" class="content-area col-md-12">
			<main id="main" class="site-main fundraiser-list" role="main">
				<div id="posts-loop" class="home-layout">
                    <div class='home-serach'>
                        <h1><?php echo get_field('into_title');?></h1>
                    </div>
                      <div class='home-category-search'>
                         <div class="owl-carousel owl-theme fundraiser-category">
                           <?php    $terms = get_terms( 'fundraiser-type' ,array('hide_empty' => 0));
                             if ( ! empty( $terms ) && ! is_wp_error( $terms ) ){
                                
                                 foreach ( $terms as $term ) {
                                     $icon = get_field('icon', $term);
                                  ?>
                                    <div class="item" ><a href="<?php echo site_url('our-stories').'/'.$term->slug;?>">
                                        <div class='icon-container'><div class='icon'><img src='<?php echo $icon['url'] ?>'></div></div>
                                        <h4><?php echo $term->name;?></h4></a></div>
                                <?php

                                 }
                                
                             } ?>
                            
                            
                        </div>
                    </div>
                    <form class="job_filters" action='<?php echo site_url();?>/our-stories/' method='post'>
	
	<div class="search_jobs">
		
		<div class="search_keywords"> 
			<input type="text" name="search_keywords" id="search_keywords" placeholder="Search by name, cause or fundraiser" value="">
		</div>
 

				 
					<div class="search_submit">
				<input type="submit" name="submit" value="Search">
			</div>
		
			</div>

	 
	<input type="hidden" name="filter_job_type[]" value="">
<div class="showing_jobs " style="display: none;"></div></form>
                     <?php 
					$args = array(	'post_type' => 'fundraiser',
					'posts_per_page' => -1, 
                    'tax_query' => array(
						array(
							'taxonomy' => 'fundraiser-status',
							'field' => 'slug',
							'terms' => 'ongoing',
						),
					),	
					'orderby'   => 'ID',
					'order' => 'ASC',
					);
					$loop = new WP_Query($args);
					$i=0;
					if($loop->have_posts()) {
						while($loop->have_posts()) : $loop->the_post();
							$i++;
							$featuredimage = wp_get_attachment_image_src( get_post_thumbnail_id( get_the_ID() ), 'full' ); 
                            $fundraiser_type = wp_get_post_terms(get_the_ID(), 'fundraiser-type', array("fields" => "all"));
							 ?>
					<article id="post-2048" class="  post type-post status-publish format-standard has-post-thumbnail hentry category-featured tag-content-2 tag-preview">
                        <div class='inner-box'>
						<div class="entry-thumb">
							<a href="<?php echo get_permalink()?>" title="<?php echo get_the_title();?>" >
								<div class="thumb-icon"><i class="fa fa-link"></i></div>
									<?php if(is_user_logged_in()) { ?>
												<div class='fundraiser-image' width="750" height="499" style="background:url('<?php echo $featuredimage[0];?>')" ></div>			
								
							<?php  } else{ ?>
				<div class='fundraiser-image' width="750" height="499" style="background:url('<?php echo site_url('blur').'/?fid='.get_the_ID();?>')" ></div>			
	 								
							<?php  } ?>
							</a>
							<span class="cat-link">
							<a href="<?php echo site_url('fundraisers')?>/<?php echo $fundraiser_type[0]->slug;?>"><?php echo $fundraiser_type[0]->name ?></a>			</span>			
						</div>
						<div class="post-content no-thumb">
							<header class="entry-header">
								<h1 class="entry-title"><a href="<?php echo get_permalink()?>" rel="bookmark"><?php echo get_the_title();?></a></h1>
								 
								<!-- .entry-meta -->
							</header>
							<!-- .entry-header -->
							<div class="entry-summary">
								<p><?php echo get_the_excerpt();?>[&hellip;]</p>
							</div>
						</div>
						</div>
					</article>
				 <?php
					 
						endwhile;
						wp_reset_postdata();
					} ?>
					<!-- #post-## -->					
				</div>
				<!--<nav class="navigation paging-navigation container clearfix" role="navigation">
					<div class="nav-links">
						<div class="nav-previous"><a href="<?php echo site_url('fundraisers')?>" > View all fundraisers&nbsp;<i class="fa fa-long-arrow-right"></i> </a></div>
					</div>
					 
				</nav>-->
				<!-- .navigation -->
			</main>
			<!-- #main -->
		</div>
	<?php
	endwhile;  
	get_footer();?> 

<script>
	jQuery(document).ready(function() {
 jQuery('.fundraiser-category').owlCarousel({
    loop:true,
    margin:10,
    nav:true,
    dots:false,
    responsive:{
        0:{
            items:1
        },
        600:{
            items:3
        },
        1000:{
            items:5
        }
    }
})
		});
</script>