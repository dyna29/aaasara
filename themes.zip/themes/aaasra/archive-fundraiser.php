<?php
    get_header();
    $fundraiser_category = get_query_var('fundraiser_category');

	 while ( have_posts() ) : the_post();
	 $homefeaturedimage = wp_get_attachment_image_src( get_post_thumbnail_id( get_the_ID() ), 'full' ); 
	 
	  
 ?> 
   <div id="primary" class="content-area col-md-12">
			<main id="main" class="site-main" role="main">
				<div id="posts-loop" class="home-layout">
                    <div class='home-serach'>
                        <h1>Thousands are fundraising online on Aaasra</h1>
                    </div>
                      <div class=' category-search'>
                         <div class="owl-carousel owl-theme fundraiser-category">
                     
                    </div>
                    
                     <?php 
					$args = array(	'post_type' => 'fundraiser',
					'posts_per_page' => 9, 
					'orderby'   => 'ID',
					'order' => 'ASC',
					);
                          
                    if($fundraiser_category !='')
                    {
                        $args['tax_query'] = array(
                                                    array (
                                                        'taxonomy' => 'fundraiser-type',
                                                        'field' => 'slug',
                                                        'terms' => $fundraiser_category,
                                                    )
    		                                     );
                    }					
                    $loop = new WP_Query($args);
					$i=0;
					if($loop->have_posts()) {
						while($loop->have_posts()) : $loop->the_post();
							$i++;
							$featuredimage = wp_get_attachment_image_src( get_post_thumbnail_id( get_the_ID() ), 'full' ); 
                            $fundraiser_type = wp_get_post_terms(get_the_ID(), 'fundraiser-type', array("fields" => "all"));
							 ?>
					<article id="post-2048" class="  post type-post status-publish format-standard has-post-thumbnail hentry category-featured tag-content-2 tag-preview">  <div class='inner-box'>
						<div class="entry-thumb">
							<a href="<?php echo get_permalink()?>" title="<?php echo get_the_title();?>" >
								<div class="thumb-icon"><i class="fa fa-link"></i></div>
								<div class='fundraiser-image' width="750" height="499" style="background:url('<?php echo $featuredimage[0];?>')" /></div>			
							</a>
							<span class="cat-link">
							<a href="<?php echo site_url('fundraisers')?>/<?php echo $fundraiser_type[0]->slug;?>"><?php echo $fundraiser_type[0]->name ?></a>			</span>			
						</div>
						<div class="post-content no-thumb">
							<header class="entry-header">
								<h1 class="entry-title"><a href="<?php echo get_permalink()?>" rel="bookmark"><?php echo get_the_title();?></a></h1>
								 
								<!-- .entry-meta -->
							</header>
							<!-- .entry-header -->
							<div class="entry-summary">
								<p><?php echo get_the_excerpt();?>[&hellip;]</p>
							</div>
						</div>
						</div>
					</article>
				 <?php
					 
						endwhile;
						wp_reset_postdata();
					} ?>
					<!-- #post-## -->					
				</div>
				<nav class="navigation paging-navigation container clearfix" role="navigation">
					<div class="nav-links">
						<div class="nav-previous"><a href="javascript:void(0)" >Load more fundraisers </a></div>
					</div>
					<!-- .nav-links -->
				</nav>
				<!-- .navigation -->
			</main>
			<!-- #main -->
		</div>
	<?php
	endwhile;  
	get_footer();?> 

<script>
	jQuery(document).ready(function() {
 jQuery('.fundraiser-category').owlCarousel({
    loop:true,
    margin:10,
    nav:true,
    dots:false,
    responsive:{
        0:{
            items:1
        },
        600:{
            items:3
        },
        1000:{
            items:5
        }
    }
})
		});
</script>