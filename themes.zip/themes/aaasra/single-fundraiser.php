<?php

	get_header();
	 while ( have_posts() ) : the_post();
	 	$featuredimage = wp_get_attachment_image_src( get_post_thumbnail_id( get_the_ID() ), 'full' ); 
        $fundraiser_type = wp_get_post_terms(get_the_ID(), 'fundraiser-type', array("fields" => "all"));
        $fundraiser_status = wp_get_post_terms(get_the_ID(), 'fundraiser-status', array("fields" => "all"));
 
			
 
 ?> 
<h1 class='fundraiser-single'><?php echo get_the_title();?></h1>
 <?php if($fundraiser_status[0]->slug=='ongoing'){ ?>
   <div id="primary" class="content-area fundraiser-single col-md-9">
			<main id="main" class="site-main" role="main">
				 
           
          
                    
                 <article id="post-2048" class="  post type-post status-publish format-standard has-post-thumbnail hentry category-featured tag-content-2 tag-preview">
						<div class="entry-thumb">
							<a href="<?php echo get_permalink()?>" title="<?php echo get_the_title();?>" ></a>
								 	<?php if(is_user_logged_in()) { ?>
								<div class='fundraiser-image' width="750" height="499" style="background:url('<?php echo $featuredimage[0];?>')" ></div>	
								
							<?php  } else{ ?>

	 <div class='fundraiser-image' width="750" height="499" style="background:url('<?php echo site_url('blur').'/?fid='.get_the_ID();?>')" ></div>								
							<?php  } ?>
							<span class="cat-link">
							<a href="<?php echo site_url('fundraisers')?>/<?php echo $fundraiser_type[0]->slug;?>"><?php echo $fundraiser_type[0]->name ?></a>			</span>			
						</div>
						<div class="post-content no-thumb">
					 
							<!-- .entry-header -->
							<div class="entry-summary">
								 <?php  the_content();?>  
							</div>
							
						<?php if(is_user_logged_in()) { ?>
						<!-- .entry-header -->
							<div class="entry-summary">
								 <?php  echo get_field('more_info');?> <div class="owl-carousel owl-theme" id='fundraiser-gallery'>
								
								 <?php 
									// loop through the rows of data
									while ( have_rows('images') ) : the_row();

										// display a sub field value
										$image = get_sub_field('image');
								?>
								
								
    <div class="item"> <div class='fundraiser-images' style="background:url('<?php echo $image['url'];?>')" href="<?php echo $image['url'];?>" data-fancybox-group="gallery" class="overlay-box lightbox-image zoom img-fluid"   > </div></div>

								
            <?php
    endwhile;
	?></div>
							</div>
                            <?php if(is_user_logged_in()) {
                                
             $current_user = wp_get_current_user();
  
 
   $user_email =  $current_user->user_email  ;
    $user_display_name      =  $current_user->display_nameqe  ;                    ?>
							 <div class='login-btn-container donate bottom-box'><a href='javascript:void(0)' class='donate-bottom-button'>Contact me for contribution</a></div>
							<?php } else { ?>
                            
                             <div class='login-btn-container donate bottom-box'><a href='javascript:void(0)' class='donate-bottom-button'>Donate Now</a></div>
							<?php } ?>
							
							<div class='donate-form'>
								<div class='row'>
									<div class='col-md-4'>
										<label>Amount</label>
									</div>
									<div class='col-md-8'>
										<select class='form-input' id='currency'>
										<option value='Rupees'>Rupees</option>
										</select>
										<input type='number' id='amount'class='form-input' ><input type='hidden' id='fundraiser_id'class='form-input' value='<?php echo get_the_ID();?>' >
									</div>
								</div>
							 <div class='row'>
									<div class='col-md-4'>
										<label>Name</label>
									</div>
									<div class='col-md-8'> 
										<input type='text' id='uname'class='form-input' value='<?php echo $user_display_name; ?>'  placeholder='Enter Your Name' >
									</div>
								</div>
									 
									<div class='row'>
									<div class='col-md-4'>
										<label>Phone Number</label>
									</div>
									<div class='col-md-8'> 
										<input type='text' id='uphone'class='form-input' placeholder='Enter Phone Number' >
									</div>
								</div>
									<div class='row'>
									<div class='col-md-4'>
										<label>WhatsApp</label>
									</div>
									<div class='col-md-8'> 
										<input type='text' id='uwhatsapp'class='form-input' placeholder='WhatsApp' >
									</div>
								</div>
                                <div class='row'>
									<div class='col-md-4'>
										<label>Email Address</label>
									</div>
									<div class='col-md-8'> 
										<input type='text' id='uemail'class='form-input' value='<?php echo $user_email; ?>'  >
									</div>
								</div>
                                <div class='row'>
									<div class='col-md-4'>
										<label>Message</label>
									</div>
									<div class='col-md-8'> 
                                        <textarea type='text' id='umessage'class='form-input' placeholder='Message' ></textarea>
									</div>
								</div>
									<div class='row'>
									<div class='col-md-12'>
										<a href='javascript:void(0)' class='submit-request'>Submit</a>
									</div>
									 
								</div>
							</div>
						<?php  } ?>
						</div>
						
					</article>
					<!-- #post-## -->					
				</div>
        <div id="side-bar" class="content-area col-md-3">	
			
			 <?php  $x = get_field('raised');
                 //   $total = get_field('amount');;
                 //   
                 		$args = array(	'post_type' => 'pledge',
					'posts_per_page' =>  -1,
					'meta_query' => array(
						 'relation' => 'AND',
						array(
							'key' => 'fundraiser',
	'value' =>  get_the_ID(),
	'compare' => '='
						),
						
						array(
							'key' => 'payment_status',
	'value' =>  'YES',
	'compare' => '='
						),
					),					
					'orderby'   => 'ID',
					'order' => 'ASC',
					);
					$loop = new WP_Query($args);
					$i=0;
$total_raised =  0;
					if($loop->have_posts()) {
						while($loop->have_posts()) : $loop->the_post();
						$amount = get_field('amount');
					 
					    $total_raised  = $total_raised  + $amount;
						endwhile;
						wp_reset_postdata();
					}
				 
                    $total = $total_raised;
				$x =get_field('amount');
                    $percentage = ($total*100)/$x;
        
                ?>
             <div id="side-bar-inner" >	 <h3 class='raised'>Rupees. <?php echo $total;?> <span>raised</span></h3>
            <div id="myProgress">
              
               
              <div id="myBar" style=" width: <?php echo $percentage;?>%;"></div>
            </div>
                  <h4 class='goal'><span>Goal</span> Rupees. <?php echo $x;?> </h4>
                 <?php if(is_user_logged_in()) { ?>
				  <div class='login-btn-container donate'><a href='javascript:void(0)' class='donate-side-button'>Contact me for contribution</a></div>
				 <?php } else { ?>
                  <div id="login-box">
                      <span>Login to view more details and donate</span>
                      <hr>
                      <div class='login-btn-container'><a href='<?php echo site_url('login-register'); ?>'>Login / Sign Up Now</a></div>
                 </div>
				 <?php } ?>
                  <div id="beneficiary-box">
                      
                      <div class='beneficiary-container'><a href='<?php echo site_url('user-details'); ?>'><span>Beneficiary:</span> <?php echo get_field('beneficiary');?></a></div>
                 </div>
				</div>
				</div>
			 <?php }else{ ?>
        <div id="primary" class="content-area <?php echo $fundraiser_status[0]->slug;?> fundraiser-single col-md-9">
			<main id="main" class="site-main" role="main">
				 
           
          
                    
                 <article id="post-2048" class="  post type-post status-publish format-standard has-post-thumbnail hentry category-featured tag-content-2 tag-preview">
						<div class="entry-thumb">
							<a href="<?php echo get_permalink()?>" title="<?php echo get_the_title();?>" ></a>
								 	<?php if(is_user_logged_in()) { ?>
								<div class='fundraiser-image' width="750" height="499" style="background:url('<?php echo $featuredimage[0];?>')" ></div>	
								
							<?php  } else{ ?>

	 <div class='fundraiser-image' width="750" height="499" style="background:url('<?php echo site_url('blur').'/?fid='.get_the_ID();?>')" ></div>								
							<?php  } ?>
							<span class="cat-link">
							<a href="<?php echo site_url('fundraisers')?>/<?php echo $fundraiser_type[0]->slug;?>"><?php echo $fundraiser_type[0]->name ?></a>			</span>			
						</div>
						<div class="post-content no-thumb">
					 
							<!-- .entry-header -->
							<div class="entry-summary">
								 <?php  the_content();?>  
							</div>
							
						<?php if(is_user_logged_in()) { ?>
						<!-- .entry-header -->
							<div class="entry-summary">
								 <?php  echo get_field('more_info');?> <div class="owl-carousel owl-theme" id='fundraiser-gallery'>
								
								 <?php 
									// loop through the rows of data
									while ( have_rows('images') ) : the_row();

										// display a sub field value
										$image = get_sub_field('image');
								?>
								
								
    <div class="item"> <div class='fundraiser-images' style="background:url('<?php echo $image['url'];?>')" href="<?php echo $image['url'];?>" data-fancybox-group="gallery" class="overlay-box lightbox-image zoom img-fluid"   > </div></div>

								
            <?php
    endwhile;
	?></div>
							</div>
                
						 
						<?php  } ?>
						</div>
						
					</article>
					<!-- #post-## -->					
				</div>
        <div id="side-bar" class="content-area col-md-3">	
			
			 <?php  $x = get_field('raised');
                 //   $total = get_field('amount');;
                 //   
                 		$args = array(	'post_type' => 'pledge',
					'posts_per_page' =>  -1,
					'meta_query' => array(
						 'relation' => 'AND',
						array(
							'key' => 'fundraiser',
	'value' =>  get_the_ID(),
	'compare' => '='
						),
						
						array(
							'key' => 'payment_status',
	'value' =>  'YES',
	'compare' => '='
						),
					),					
					'orderby'   => 'ID',
					'order' => 'ASC',
					);
					$loop = new WP_Query($args);
					$i=0;
$total_raised =  0;
					if($loop->have_posts()) {
						while($loop->have_posts()) : $loop->the_post();
						$amount = get_field('amount');
					 
					    $total_raised  = $total_raised  + $amount;
						endwhile;
						wp_reset_postdata();
					}
				 
                    $total = $total_raised;
				$x =get_field('amount');
                    $percentage = ($total*100)/$x;
        
                ?>
             
				</div>
			 <?php } ?>
				<!-- .navigation -->
			</main>
			<!-- #main -->
		</div>
	<?php
	endwhile;  
	get_footer();?> 

<script>
	jQuery(document).ready(function() {
		jQuery("#fundraiser-gallery").magnificPopup({
				delegate: ".fundraiser-images",
				type: "image",
				tLoading: "Loading image #%curr%...",
				mainClass: "mfp-img-mobile",
				gallery: {
					enabled: true,
					navigateByImgClick: false,
					preload: [0,1] // Will preload 0 - before current, and 1 after the current image
				},
				image: {
					tError: '<a href="%url%">The image #%curr%</a> could not be loaded.',				
				}
			});
jQuery('#fundraiser-gallery').owlCarousel({
    loop:true,
    margin:10,
    nav:true,dots:false,
    responsive:{
        0:{
            items:1
        },
        600:{
            items:3
        },
        1000:{
            items:3
        }
    }
})
		});
</script>