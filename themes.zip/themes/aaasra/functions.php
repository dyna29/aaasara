<?php
show_admin_bar( false ); 

if (function_exists('add_theme_support')) {
  
    register_nav_menus(array(
        'user_navigation' => __('User Navigation', 'aaasra')
    )); 
    register_nav_menus(array(
        'user_navigation_mobile' => __('User Navigation Mobile', 'aaasra')
    )); 
    register_nav_menus(array(
        'navigation_mobile' => __('Navigation Mobile', 'aaasra')
    )); 
   
}
add_action('admin_footer', 'my_custom_scripts');

function my_custom_scripts() {
  echo '<script> ';
   echo 'jQuery(".noedit select").attr("readonly", true); ';
   echo 'jQuery(".noedit input").attr("readonly", true); ';
	echo 'jQuery(".noedit").find(".select2-hidden-accessible").attr("width","100%");';
	echo 'jQuery(".noedit").find(".select2-hidden-accessible").attr("height","40px");';
	echo 'jQuery(".noedit").find(".select2-hidden-accessible").attr("position","relative !important");';
	
	echo 'jQuery(".noedit").find(".select2-container").attr("display","none");';
   echo '</script>;';
}
add_action( 'wp_enqueue_scripts', 'my_theme_enqueue_styles' );
function my_theme_enqueue_styles() {
 
    $parent_style = 'parent-style'; // This is 'twentyfifteen-style' for the Twenty Fifteen theme.
 
    wp_enqueue_style('carousel', get_stylesheet_directory_uri() . '/css/owl.carousel.min.css');
    wp_enqueue_style('carousel-theme', get_stylesheet_directory_uri() . '/css/owl.theme.default.min.css');
    wp_enqueue_style('magnific', get_stylesheet_directory_uri() . '/css/magnific-popup.css');
    wp_enqueue_style( $parent_style, get_template_directory_uri() . '/style.css', array( 'alizee-bootstrap' ),
        wp_get_theme()->get('Version') );
   
}

function theme_enqueue_scripts()
{
     wp_enqueue_script('magnific', get_stylesheet_directory_uri() . '/js/jquery.magnific-popup.min.js', array( 'jquery'), '20161929',true); 
     wp_enqueue_script('carousel', get_stylesheet_directory_uri() . '/js/owl.carousel.min.js', array( 'jquery'), '20161929',true); 
    
       wp_register_script('global-var', get_stylesheet_directory_uri() . '/js/script.js', array( 'jquery'), '20161929',true);
    $globalvar = array( "siteurl" => site_url(), "assets" => get_stylesheet_directory_uri(), "ajax_url" => admin_url('admin-ajax.php'));
    wp_localize_script('global-var', 'globalvar', $globalvar);
    
    // Enqueued script with localized data.
    wp_enqueue_script('global-var');
}
add_action('wp_enqueue_scripts', 'theme_enqueue_scripts');

function custom_post_init()
{
 
    $labels = array(
        'name' => _x('Fundraiser', 'post type general name', 'aaasra'),
        'singular_name' => _x('Fundraiser', 'post type singular name', 'aaasra'),
        'menu_name' => _x('Fundraisers', 'admin menu', 'aaasra'),
        'name_admin_bar' => _x('Fundraiser', 'add new on admin bar', 'aaasra'),
        'add_new' => _x('Add New Fundraiser', 'hotel', 'aaasra'),
        'add_new_item' => __('Add New Fundraiser', 'aaasra'),
        'new_item' => __('New Fundraiser', 'aaasra'),
        'edit_item' => __('Edit Fundraiser', 'aaasra'),
        'view_item' => __('View Fundraiser', 'aaasra'),
        'all_items' => __('All Fundraisers', 'aaasra'),
        'search_items' => __('Search Fundraisers', 'aaasra'),
        'parent_item_colon' => __('Parent Fundraisers:', 'aaasra'),
        'not_found' => __('No Fundraisers found.', 'aaasra'),
        'not_found_in_trash' => __('No Fundraisers found in Trash.', 'aaasra')
    );
    $args   = array(
        'labels' => $labels,
        'description' => __('Description.', 'aaasra'),
        'public' => true,
        'publicly_queryable' => true,
        'show_ui' => true,
        'show_in_menu' => true,
        'query_var' => true,
        'rewrite' => array(
            'slug' => 'fundraiser'
        ),
        'capability_type' => 'post',
        'has_archive' => true,
        'hierarchical' => false,
        'menu_position' => null,
        'supports' => array(
            'title',
            'editor',
            'thumbnail',
            'excerpt'
        )
    );
    register_post_type('fundraiser', $args);
    $labels = array(
        'name' => _x('Pledge', 'post type general name', 'aaasra'),
        'singular_name' => _x('Pledge', 'post type singular name', 'aaasra'),
        'menu_name' => _x('Pledges', 'admin menu', 'aaasra'),
        'name_admin_bar' => _x('Pledge', 'add new on admin bar', 'aaasra'),
        'add_new' => _x('Add New Pledge', 'hotel', 'aaasra'),
        'add_new_item' => __('Add New Pledge', 'aaasra'),
        'new_item' => __('New Pledge', 'aaasra'),
        'edit_item' => __('Edit Pledge', 'aaasra'),
        'view_item' => __('View Pledge', 'aaasra'),
        'all_items' => __('All Pledges', 'aaasra'),
        'search_items' => __('Search Pledges', 'aaasra'),
        'parent_item_colon' => __('Parent Pledges:', 'aaasra'),
        'not_found' => __('No Pledges found.', 'aaasra'),
        'not_found_in_trash' => __('No Pledges found in Trash.', 'aaasra')
    );
    $args   = array(
        'labels' => $labels,
        'description' => __('Description.', 'aaasra'),
        'public' => true,
        'publicly_queryable' => true,
        'show_ui' => true,
        'show_in_menu' => true,
        'query_var' => true,
        'rewrite' => array(
            'slug' => 'pledge'
        ),
        'capability_type' => 'post',
        'has_archive' => true,
        'hierarchical' => false,
        'menu_position' => null,
        'supports' => array(
            'title',
            'editor',
            'thumbnail',
            'excerpt'
        )
    );
    register_post_type('pledge', $args);
	   
}
add_action('init', 'custom_post_init');
function custom_taxonomy_init()
{
    
    
    
    $labels = array(
        'name' => _x('Fundraiser Type', 'taxonomy general name'),
        'singular_name' => _x('Fundraiser Type', 'taxonomy singular name'),
        'search_items' => __('Search Fundraiser Type'),
        'all_items' => __('All Fundraiser Type'),
        'parent_item' => __('Parent Fundraiser Type'),
        'parent_item_colon' => __('Parent Fundraiser Type:'),
        'edit_item' => __('Edit Fundraiser Type'),
        'update_item' => __('Update Fundraiser Type'),
        'add_new_item' => __('Add New Fundraiser Type'),
        'new_item_name' => __('New Fundraiser Type'),
        'menu_name' => __('Fundraiser Type')
    );
    
    $args = array(
        'hierarchical' => true,
        'labels' => $labels,
        'show_ui' => true,
        'show_admin_column' => true,
        'query_var' => true,
        'rewrite' => array(
            'slug' => 'fundraiser-type'
        )
    );
    register_taxonomy('fundraiser-type', array(
        'fundraiser'
    ), $args);  
    
    $labels = array(
        'name' => _x('Fundraiser Status', 'taxonomy general name'),
        'singular_name' => _x('Fundraiser Status', 'taxonomy singular name'),
        'search_items' => __('Search Fundraiser Status'),
        'all_items' => __('All Fundraiser Status'),
        'parent_item' => __('Parent Fundraiser Status'),
        'parent_item_colon' => __('Parent Fundraiser Status:'),
        'edit_item' => __('Edit Fundraiser Status'),
        'update_item' => __('Update Fundraiser Status'),
        'add_new_item' => __('Add New Fundraiser Status'),
        'new_item_name' => __('New Fundraiser Status'),
        'menu_name' => __('Fundraiser Status')
    );
    
    $args = array(
        'hierarchical' => true,
        'labels' => $labels,
        'show_ui' => true,
        'show_admin_column' => true,
        'query_var' => true,
        'rewrite' => array(
            'slug' => 'fundraiser-status'
        )
    );
    register_taxonomy('fundraiser-status', array(
        'fundraiser'
    ), $args);
    
}
add_action('init', 'custom_taxonomy_init');
 
 function fund_page_rules() { 
	 add_rewrite_rule('our-stories/?([^/]*)', 'index.php?pagename=our-stories&fundraiser_category=$matches[1]', 'top');
	 add_rewrite_rule('success-stories/?([^/]*)', 'index.php?pagename=success-stories&fundraiser_category=$matches[1]', 'top');
 }

 function fund_page_query_vars($vars) {
      $vars[] = 'fundraiser_category';
      return $vars;
 }
 
  
 add_action('init', 'fund_page_rules');

 add_filter('query_vars', 'fund_page_query_vars');
 add_filter( 'posts_where', 'wpse18703_posts_where', 10, 2 );
function wpse18703_posts_where( $where, &$wp_query )
{
    global $wpdb; 
	$queryelemenet = $wp_query->query; 
	if($queryelemenet['docname']==1){
		if(isset($_REQUEST['search_keywords'])){				
			$search_keywords = $_REQUEST['search_keywords'];
			if($search_keywords  !='all'){
				 $where .= ' AND ' . $wpdb->posts . '.post_title LIKE \'%' . esc_sql( $wpdb->esc_like( $search_keywords ) ) . '%\'';
			}				 
		}
	}

 unset($array[1]);
    return $where;
}
 

 
function aasra_set_user_role($user_id){
    $user = new WP_User( $user_id );
	$user->set_role( 'supporter' );
	wp_set_current_user ( $user_id);
    wp_set_auth_cookie  ( $user_id );
	return;
   
}
 add_action('user_register','aasra_set_user_role',10,1);
 
add_action( 'wp_logout', 'auto_redirect_external_after_logout');
function auto_redirect_external_after_logout(){
  wp_redirect( site_url() );
  exit();
}
 
 add_action('wp_ajax_nopriv_submit_donation_request', 'submit_donation_request');
add_action('wp_ajax_submit_donation_request', 'submit_donation_request');

function submit_donation_request()
{ 
    $amount            = esc_sql($_REQUEST["amount"]);
    $umessage           = esc_sql($_REQUEST["umessage"]);
    $uwhatsapp           = esc_sql($_REQUEST["uwhatsapp"]);
    $uemail            = esc_sql($_REQUEST["uemail"]);
    $uphone         = esc_sql($_REQUEST["uphone"]);
    $uname        = esc_sql($_REQUEST["uname"]);
    $currency         = esc_sql($_REQUEST["currency"]);
    $fundraiser_id          = esc_sql($_REQUEST["fundraiser_id"]);
       $current_user = wp_get_current_user();
  
 
  // $uname =  $current_user->display_name  ;
 //  $uemail =  $current_user->user_email  ;
  
      $id = wp_insert_post(array( 
            'post_type' => 'pledge', 
            'post_status' => 'publish', 'post_title'   => 'Pledge  (Name: '.$uname.')', 
        ));
		
		 
		 $my_post = array(
      'ID'           =>  $id ,
      'post_title'   => 'Pledge - '.$id.' (Name: '.$uname.'  / Fundraiser: '.get_the_title($fundraiser_id).'  )', 
  );

// Update the post into the database
  wp_update_post( $my_post );
 
	 update_post_meta($id, 'amount', $amount);
	 update_post_meta($id, 'uname', $uname);
	 update_post_meta($id, 'email', $uemail);
	 update_post_meta($id, 'phone', $uphone);
	 update_post_meta($id, 'currency', $currency);
 update_post_meta($id, 'message', $umessage);
 update_post_meta($id, 'whatsapp', $uwhatsapp);
	 update_post_meta($id, 'fundraiser', $fundraiser_id);
	 update_post_meta($id, 'system_user', get_current_user_id());
    $to        =  'fahishar@gmail.com';
    $headers[] = 'From: AAASRA  <no-reply@aaasra.com>' . "\r\n";
       $headers[] = 'BCC:  <dyna29@gmail.com>' . "\r\n";
    $headers[] = 'BCC:  <dyna29@mailinator.com>' . "\r\n";
    $headers[] = 'BCC:  <rizwanahmedhn@gmail.com>' . "\r\n";
    $body      = 'Hi Admin';
    $body    .= '<br><br>We have recieved the following pledge:';
    $body .= '<br><b>Name:</b>' . $uname; 
    $body .= '<br><b>Email:</b>' . $uemail;  
    $body .= '<br><b>Phone:</b>' . $uphone; 
    $body .= '<br><b>WhatsApp:</b>' . $uwhatsapp; 
    $body .= '<br><b>Message:</b>' . $umessage; 
    $body .= '<br><b>Amount Pledged:</b>' . $currency.'. '. $amount; 
    $body .= '<br><b>System ID:</b>' . get_current_user_id(); 
    $body .= '<br><b>URL:</b> '.site_url().'/wp-admin/post.php?post='.$id.'&action=edit'; 
 
   
	    $body  .= '<br><br>Regards,<br>AAASRA <br>';
		 
    $headers[] = 'Content-Type: text/html; charset=UTF-8';
    $mail      = wp_mail($to, 'Donation Pledge: (Name: '.$uname.'  / Fundraiser: '.get_the_title($fundraiser_id).'  )', $body, $headers);
    $result = 1;
    echo json_encode($result );
    die();
}

// Function to change email address
 
function wpb_sender_email( $original_email_address ) {
    return 'no-reply@aaasra.com';
}
 
// Function to change sender name
function wpb_sender_name( $original_email_from ) {
    return 'AAASRA';
}
 
// Hooking up our functions to WordPress filters 
add_filter( 'wp_mail_from', 'wpb_sender_email' );
add_filter( 'wp_mail_from_name', 'wpb_sender_name' );