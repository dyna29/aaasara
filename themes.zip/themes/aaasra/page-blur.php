<?php

header('Content-type: image/jpeg');
 if(isset($_REQUEST['fid'])){
$featuredimage = wp_get_attachment_image_src( get_post_thumbnail_id( $_REQUEST['fid'] ), 'full' ); 
$image_url = $featuredimage[0];
 }else{
	 $image_url =  get_stylesheet_directory_uri().'image/no-image.png';
 }
$image = new Imagick($image_url);

$image->blurImage(20,30);
echo $image;

?>