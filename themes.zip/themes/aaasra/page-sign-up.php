<?php
       get_header('signup');
    $fundraiser_category = get_query_var('fundraiser_category');

	 while ( have_posts() ) : the_post();
	 $homefeaturedimage = wp_get_attachment_image_src( get_post_thumbnail_id( get_the_ID() ), 'full' ); 
	 
 ?>  <?php if(is_user_logged_in()) { ?>
 <script> location.href='<?php echo site_url();?>' </script>
 <?php } ?>
   <div id="primary" class="content-area col-md-12">
			<main id="main" class="site-main register-main" role="main">
			 
		
			<div   class="sign-up-layout register">
				<div class='row'>
                    <div class='col-md-8 intro-logo-area'> 
						<h1>Welcome To</h1>
						<?php if ( get_theme_mod('site_logo') ) : ?>
					<a href="<?php echo esc_url( home_url( '/' ) ); ?>" title="<?php bloginfo('name'); ?>"><img src="<?php echo esc_url(get_theme_mod('site_logo')); ?>" alt="<?php bloginfo('name'); ?>" /></a>
					<?php endif; ?>
					
					<h4>Aready have an user account with Aaasra?  <a href='<?php echo site_url('login-register')?>'>Login now</a> </h4>
					</div> <div class='col-md-4 form-area'> 
						 <?php echo do_shortcode('[wpmp_register_form]');?> 
					
					</div>
					</div>
			</div>
			</main>
			</div>
	<?php
	endwhile;  
	get_footer();?> 

<script>
	jQuery(document).ready(function() {
 jQuery('#redirection_url').val('<?php echo site_url();?>')
		});
</script>