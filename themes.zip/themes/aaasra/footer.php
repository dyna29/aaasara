<?php
/**
 * The template for displaying the footer.
 *
 * Contains the closing of the #content div and all content after
 *
 * @package Alizee
 */
?>

	</div><!-- #content -->
	<?php if ( is_active_sidebar( 'sidebar-3' ) ) {
		get_sidebar('footer');
	} ?>

	<footer id="colophon" class="site-footer" role="contentinfo">
		<div class="site-info">
			<div class="container">
				<a href="<?php echo esc_url( __( 'http://kdakw.com/', 'alizee' ) ); ?>" target='_blank'><?php printf( __( 'Powered by %s', 'alizee' ), 'KDA' ); ?></a>
				<span class="sep"> | </span>
				© 2019 aasra.com. All rights reserved.
			</div>
		</div><!-- .site-info -->
	</footer><!-- #colophon -->
</div><!-- #page -->

<?php wp_footer(); 

  $current_user = wp_get_current_user();
  
 
   $display_name =  $current_user->display_name  ;
 
?>




<script>
	jQuery(document).ready(function() {
		
		if(jQuery('.logout-link').length>0){
			logouturl = '<?php echo wp_logout_url(); ?>'
			logouturl = logouturl.replace("&amp;", "&");
			jQuery('.logout-link').find('a').attr('href',logouturl);
			
			jQuery('.welcome-user > a').html('Welcome <?php echo $display_name ?>')
		}
 
		});
</script>
</body>
</html>
