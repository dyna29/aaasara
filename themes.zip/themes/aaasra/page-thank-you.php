<?php
    get_header();
    
	 while ( have_posts() ) : the_post();
	 $homefeaturedimage = wp_get_attachment_image_src( get_post_thumbnail_id( get_the_ID() ), 'full' ); 
	 
 ?> 
   <div id="primary" class="content-area col-md-12">
			<main id="main" class="site-main" role="main">
				<div id="posts-loop" class="home-layout">
                    <div class='home-serach'>
                        <h1>Thank you , your contribution mail has been sent. Will get back to you soon</h1>
                    </div>
					<p class='pink-link'>Continue browsing more <a href='<?php echo site_url('fundraiser')?>'>fundraisers</a></p>
                      
			
				<!-- .navigation -->
			</main>
			<!-- #main -->
		</div>
	<?php
	endwhile;  
	get_footer();?> 

<script>
	jQuery(document).ready(function() {
  
		});
</script>