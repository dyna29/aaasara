<?php
    get_header();
    
	 while ( have_posts() ) : the_post();
	 $homefeaturedimage = wp_get_attachment_image_src( get_post_thumbnail_id( get_the_ID() ), 'full' ); 
	 $current_user = wp_get_current_user();
  
 
   $display_name =  $current_user->display_name  ; 
   $first_name =  $current_user->first_name  ;
   $last_name =  $current_user->last_name  ;
   $email =  $current_user->user_email  ; 
 ?> 
   <div id="primary" class="content-area col-md-12">
			<main id="main" class="site-main" role="main">
				<div id="posts-loop" class="home-layout">
                    <div class='home-serach'>
                        <h1>Welcome <?php echo $display_name;?></h1>
                    </div>
					<h3>Below are your contact information:</h3>
					
					<div class='contact-info'>
						<div class='contact-info-item'><span>First Name:</span><?php echo $first_name;?></div>
					<div class='contact-info-item'><span>Last Name:</span><?php echo $last_name;?></div>
					<div class='contact-info-item'><span>Email</span><?php echo $email;?></div>
					
					</div>
					
					 
             <div class='your-pledges'> 
			 
			 <h3>Below are your pledges:<br></h3>
             <div class='row'> 
			 
			  <?php 
					$args = array(	'post_type' => 'pledge',
					'posts_per_page' =>  -1,
					'meta_query' => array(
						array(
							'key' => 'system_user',
	'value' =>  get_current_user_id(),
	'compare' => '='
						),
					),					
					'orderby'   => 'ID',
					'order' => 'ASC',
					);
					$loop = new WP_Query($args);
					$i=0;
					if($loop->have_posts()) {
						while($loop->have_posts()) : $loop->the_post();
						$uname = get_post_meta(get_the_ID(),'uname', true);
						$amount = get_post_meta(get_the_ID(),'amount', true);
						$currency = get_post_meta(get_the_ID(),'currency', true);
						$uemail = get_post_meta(get_the_ID(),'uemail' ,true);
						$uphone = get_post_meta(get_the_ID(),'phone' ,true);
						$name = get_post_meta(get_the_ID(),'name', true);
						$fundraiser = get_post_meta(get_the_ID(),'fundraiser', true);
						?>
			 <div class='col-md-4'>
			 <div class='pledge'>
			 
			 <div class='pledge-item'><span></span><span class='highlight fundraiser'><a href='<?php echo get_permalink( $fundraiser );?>'><?php echo get_the_title($fundraiser);?></a></span></div>	
			  <div class='pledge-item'><span>Amount: </span><span class='highlight'><?php echo $currency;?>. <?php echo $amount;?></span></div>	
			  <div class='pledge-item'><span>Name: </span> <?php echo $uname;?>  </div>	
			  <div class='pledge-item'><span>Phone: </span> <?php echo $uphone;?>  </div>	
			  <div class='pledge-item'><span>Email@ </span> <?php echo $email;?>  </div>	
			</div>	
			</div>	

<?php
	endwhile;
						wp_reset_postdata();
					}else{
						
						?><h5>No records found!</h5><?php
					} ?>	
 		
			</div>			 
			</div>			 
			
				<!-- .navigation -->
			</main>
			<!-- #main -->
		</div>
	<?php
	endwhile;  
	get_footer();?> 

<script>
	jQuery(document).ready(function() {
  
		});
</script>