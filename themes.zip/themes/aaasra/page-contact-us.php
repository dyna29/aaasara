<?php
/**
 * The template for displaying all pages.
 *
 * This is the template that displays all pages by default.
 * Please note that this is the WordPress construct of pages
 * and that other 'pages' on your WordPress site will use a
 * different template.
 *
 * @package Alizee
 */

get_header(); ?>

	<div id="primary" class="content-area">
		<main id="main" class="site-main contact-page" role="main">
<div class='row'>
<div class='col-md-4'>
<h4>Get in touch</h4>
 
<div class="contact-item">
<div class="contact-icon">
<img src="<?php echo get_stylesheet_directory_uri(); ?>/images/email.png" />
</div>
<div class="contact-text">
<p><a href="mailto:<?php echo get_field('email');?>"><?php echo get_field('email');?></a></p>
</div>
</div>
  
<div class="contact-item">
<div class="contact-icon">
<img src="<?php echo get_stylesheet_directory_uri(); ?>/images/location.png" />
</div>
<div class="contact-text">
<p><?php echo get_field('address');?></p>
</div>
</div>
 
 
<div class="contact-item">
<div class="contact-icon">
<img src="<?php echo get_stylesheet_directory_uri(); ?>/images/phone.png" />
</div>
<div class="contact-text">
<p><a href="tel:<?php echo get_field('phone');?>"><?php echo get_field('phone');?></a></p>
</div>
</div>
 
</div>

<div class='col-md-8'>
			<?php echo do_shortcode('[contact-form-7 id="113" title="Contact form 1"]'); ?>

		</main><!-- #main -->
	</div><!-- #primary -->
	</div><!-- #primary -->
	</div><!-- #primary -->

<?php //get_sidebar(); ?>
<?php get_footer(); ?>
